<?php
/**
 * Performance Customizer Options
 *
 * @package Botiga
 */

// $wp_customize->add_section(
//     'botiga_section_performance',
//     array(
//         'title'    => esc_html__( 'Performance', 'botiga' ),
//         'priority' => 180
//     )
// );
